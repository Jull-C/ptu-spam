let scorePrice =[
    {
        "value": "0",
        "icon":"/assets/yellowCircle.png",
        "type": "color",
        "shade": "#f7d678",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "1",
        "icon":"/assets/blueCircle.png",
        "type": "color",
        "shade": "#9da9e5",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "3",
        "icon": "/assets/redCircle.png",
        "type": "color",
        "shade": "#e47878",
        "contrast": "white",
        "ops": "#101015"

    },
    {
        "value": "5",
        "icon":"/assets/greenCircle.png",
        "type": "color",
        "shade": "#a4dc6a",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "7",
        "icon":"/assets/orangeCircle.png",
        "type": "color",
        "shade": "#f7af78",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "9",
        "icon": "/assets/purpleCircle.png",
        "type": "color",
        "shade": "#d4a1e7",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "14",
        "icon":"/assets/yellowOrangeCircle.png",
        "type": "color",
        "shade": "#fac354",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "17",
        "icon": "/assets/lightGreenCircle.png",
        "type": "color",
        "shade": "#d1dc6a",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "20",
        "icon":"/assets/lightCyanCircle.png",
        "type": "color",
        "shade": "#9be2bc",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "24",
        "icon": "/assets/pinkCircle.png",
        "type": "color",
        "shade": "#ed8cbe",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "30",
        "icon": "/assets/bluePurpleCircle.png",
        "type": "color",
        "shade": "#8263c4",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "34",
        "icon":"/assets/darkGrayCircle.png",
        "type": "color",
        "shade": "#313131",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "38",
        "icon": "/assets/lightGrayCircle.png",
        "type": "color",
        "shade": "#808080",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "42",
        "icon":"/assets/circle.png",
        "type": "color",
        "shade": "white",
        "contrast": "#101015",
        "ops": "white"

    }

    

]
/*
let scorePrice =[
    {
        "value": "0",
        "icon":"/assets/yellowCircle.png",
        "type": "color",
        "shade": "#f7d678",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "5",
        "icon":"/assets/blueCircle.png",
        "type": "color",
        "shade": "#9da9e5",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "10",
        "icon": "/assets/redCircle.png",
        "type": "color",
        "shade": "#e47878",
        "contrast": "white",
        "ops": "#101015"

    },
    {
        "value": "18",
        "icon":"/assets/greenCircle.png",
        "type": "color",
        "shade": "#a4dc6a",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "26",
        "icon":"/assets/orangeCircle.png",
        "type": "color",
        "shade": "#f7af78",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "34",
        "icon": "/assets/purpleCircle.png",
        "type": "color",
        "shade": "#d4a1e7",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "42",
        "icon":"/assets/yellowOrangeCircle.png",
        "type": "color",
        "shade": "#fac354",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "50",
        "icon": "/assets/lightGreenCircle.png",
        "type": "color",
        "shade": "#d1dc6a",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "58",
        "icon":"/assets/lightCyanCircle.png",
        "type": "color",
        "shade": "#9be2bc",
        "contrast": "#101015",
        "ops": "white"
    },
    {
        "value": "66",
        "icon": "/assets/pinkCircle.png",
        "type": "color",
        "shade": "#ed8cbe",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "74",
        "icon": "/assets/bluePurpleCircle.png",
        "type": "color",
        "shade": "#8263c4",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "82",
        "icon":"/assets/darkGrayCircle.png",
        "type": "color",
        "shade": "#313131",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "90",
        "icon": "/assets/lightGrayCircle.png",
        "type": "color",
        "shade": "#808080",
        "contrast": "white",
        "ops": "#101015"
    },
    {
        "value": "100",
        "icon":"/assets/circle.png",
        "type": "color",
        "shade": "white",
        "contrast": "#101015",
        "ops": "white"

    }

    

]*/

import {mathSelector, scienceSelector, mixtSelector} from './ciencias_QS.js';

let subject = localStorage.getItem("subject");
let selectedList;

if(subject == null){
    localStorage.setItem("subject","mixt");
    subject = localStorage.getItem("subject");

    selectedList = mixtSelector;
}
else{//cado otro caso
    if(subject == "math") selectedList = mathSelector;
    else if (subject == "science") selectedList = scienceSelector;
    else if (subject == "mixt") selectedList = mixtSelector;
}






console.log(subject);



let nextGoalIndex = localStorage.getItem("nextGoalIndex");



let num_pregunta = Math.floor(Math.random() * selectedList.length);
console.log(selectedList.length);




document.getElementById("Pregunta").innerHTML = selectedList[num_pregunta].statement;
if(selectedList[num_pregunta].imagePath != null && selectedList[num_pregunta].imagePath != undefined){
    document.getElementById("imgForQ").src = selectedList[num_pregunta].imagePath;
    document.getElementById("imgForQ").style.display = "inline";
}
else{
    if(document.getElementById("imgForQ").style.display == "inline") document.getElementById("imgForQ").style.display = "none";
}


document.getElementById("aText").innerHTML = selectedList[num_pregunta].answer_1;
document.getElementById("bText").innerHTML = selectedList[num_pregunta].answer_2;
document.getElementById("cText").innerHTML = selectedList[num_pregunta].answer_3;
document.getElementById("dText").innerHTML = selectedList[num_pregunta].answer_4;

MathJax.typeset();

let correct = selectedList[num_pregunta].correct;
let correctRadio = document.getElementById(correct);
let correctDiv = document.getElementById(selectedList[num_pregunta].opDiv);

let resultado = document.getElementById("resultText");

let contador = localStorage.getItem("contador");


if(contador == null){
    localStorage.setItem("contador","0");
    contador = localStorage.getItem("contador");

    document.getElementById("numOfGoods").innerHTML = contador;

}
else{

    contador = localStorage.getItem("contador");

    document.getElementById("numOfGoods").innerHTML = contador;


}

if(nextGoalIndex == null){
    localStorage.setItem("nextGoalIndex","0");//startValue
    nextGoalIndex = localStorage.getItem("nextGoalIndex");
}



document.getElementById("startQs").onclick = function(){
    
    document.getElementById("startQs").style.visibility = "hidden";

    
    
    
    document.getElementById("submitButton").style.display = "inline";
    document.getElementById("wholeBox").style.display = "block";
}





let announcing = false;



document.getElementById("submitButton").onclick = function(){

    if(correctRadio.checked){
        resultado.innerHTML = "Correcto. Fantastik ;)";
        if(contador == null){
            localStorage.setItem("contador","1");
            contador = localStorage.getItem("contador");

            document.getElementById("numOfGoods").innerHTML = contador;

        }
        else{
            let newGoods = parseInt(localStorage.getItem("contador"))+1;
            localStorage.setItem("contador", String(newGoods));

            document.getElementById("numOfGoods").innerHTML = newGoods;
            contador = localStorage.getItem("contador");




        }

    

        if(scorePrice[nextGoalIndex] != null){
            console.log("contador: " + contador);
            console.log("nextPrice: " + scorePrice[nextGoalIndex]["value"]);
        }
    
        if(scorePrice[nextGoalIndex] != null && parseInt(contador) == scorePrice[nextGoalIndex]["value"]){
            console.log("YES PRICE");
            goodiesList.push(nextGoalIndex);
            
            localStorage.setItem("goodiesList",JSON.stringify(goodiesList));
            //addGoodie(nextGoalIndex);

            addGoodie(nextGoalIndex);

            if(!announcing){
                document.getElementById("anuncio").style.display = "inline";
                announcing = true;
                if(contador==42){
                    document.getElementById("anuncio").innerHTML = "último color pq no se me ocurrieron más :-]";
                    document.getElementById("anuncio").style.width = "300px";
                    document.getElementById("anuncio").style.fontSize = "20px";
                }
            }
            
    
            let newIndex = parseInt(localStorage.getItem("nextGoalIndex"))+1;
            localStorage.setItem("nextGoalIndex", String(newIndex));
            nextGoalIndex = localStorage.getItem("nextGoalIndex");
            
        }
    
        
        





    }
    else{
        resultado.innerHTML = "Buu No :(";
    }


    correctDiv.style.backgroundColor = "#4caf51";

    document.getElementById("submitButton").style.display = "none";
    document.getElementById("resultText").style.display = "block";
    document.getElementById("MoreQs").style.display = "block";


    
    
    correctRadio.style.backgroundColor = "#4caf51";


}



function renderQue(){
    correctDiv.style.backgroundColor = "transparent";
    correctRadio.style = "none";

    document.getElementById("ansA").checked = false;
    document.getElementById("ansB").checked = false;
    document.getElementById("ansC").checked = false;
    document.getElementById("ansD").checked = false;
    

    num_pregunta = Math.floor(Math.random() * selectedList.length);
    correct = selectedList[num_pregunta].correct;
    correctRadio = document.getElementById(correct);
    correctDiv = document.getElementById(selectedList[num_pregunta].opDiv);


    document.getElementById("Pregunta").innerHTML = selectedList[num_pregunta].statement;

    if(selectedList[num_pregunta].imagePath != null && selectedList[num_pregunta].imagePath != undefined){
        document.getElementById("imgForQ").src = selectedList[num_pregunta].imagePath;
        document.getElementById("imgForQ").style.display = "inline";
        document.getElementById("Pregunta").style.width = "70%";
    }
    else{
        if(document.getElementById("imgForQ").style.display == "inline") document.getElementById("imgForQ").style.display = "none";
        document.getElementById("Pregunta").style.width = "100%";
    }

    document.getElementById("aText").innerHTML = selectedList[num_pregunta].answer_1;
    document.getElementById("bText").innerHTML = selectedList[num_pregunta].answer_2;
    document.getElementById("cText").innerHTML = selectedList[num_pregunta].answer_3;
    document.getElementById("dText").innerHTML = selectedList[num_pregunta].answer_4;

    MathJax.typeset()
    
    resultado.style.display = "none";
    document.getElementById("submitButton").style.display = "inline";
    document.getElementById("resultText").style.display = "none";
    document.getElementById("MoreQs").style.display = "none";



    document.getElementsByClassName("op").unchecked = true;
}

document.getElementById("MoreQs").onclick = function(){
    renderQue();
}

//all the goodies content


//menuOpen
document.getElementById("goodiesButton").onclick = function(){
    if(announcing){
        document.getElementById("anuncio").style.display = "none";
        announcing = false;
    }
    let x = document.getElementsByClassName("goodiesItem");
    let i;
    let space = 10;
    for (i = 0; i < x.length; i++) {
        
        space += 50;
        //x[i].style.left = space + "px";
        
        if(x[i].style.display == "none"){
            x[i].style.display = "block";
        }
        else{
            x[i].style.display = "none";
        }

        

        

    }

}

//goodies onStorage
let goodiesList = JSON.parse(localStorage.getItem("goodiesList"));
if(goodiesList == null){
    let goodiesArray = [];

    localStorage.setItem("goodiesList",JSON.stringify(goodiesArray));//empty array
    goodiesList = JSON.parse(localStorage.getItem("goodiesList"));
}




function addPrevGoodies(){
    let i;
    for (i = 0; i < goodiesList.length; i++) {

        addGoodie(i);

    }
    var x = document.getElementsByClassName("goodiesItem");
    
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
}

//active goodies
let activeGoodies = localStorage.getItem("activeGoodies");
if(activeGoodies == null){
    

    localStorage.setItem("activeGoodies", "-1");//empty array
    activeGoodies = parseInt(localStorage.getItem("activeGoodies"));
}

document.body.onload = function(){
    

    addPrevGoodies();

    //adding First one
    if(parseInt(contador) == 0 && goodiesList.length == 0 && parseInt(contador) == scorePrice[nextGoalIndex]["value"]){
        console.log("YES PRICE");
        goodiesList.push(nextGoalIndex);
        
        localStorage.setItem("goodiesList",JSON.stringify(goodiesList));
        //addGoodie(nextGoalIndex);

        addGoodie(nextGoalIndex);

        if(!announcing){
            document.getElementById("anuncio").style.display = "inline";
            announcing = true;
        }
        

        let newIndex = parseInt(localStorage.getItem("nextGoalIndex"))+1;
        localStorage.setItem("nextGoalIndex", String(newIndex));
        nextGoalIndex = localStorage.getItem("nextGoalIndex");
        
    }


    if(activeGoodies != null && activeGoodies != -1){
        console.log(activeGoodies);
        applyGoodie(parseInt(activeGoodies));
    }

}




//ADD GOODIE

function addGoodie(index){

    let newGood = document.createElement("img");
    newGood.src = scorePrice[index]["icon"];
    newGood.className = "goodiesItem";
    newGood.id = "goodie_"+index;
    newGood.setAttribute('showing', 'false');
    newGood.onclick = function(){applyGoodie(index)};
    document.getElementById("allGoodies").appendChild(newGood);

    var x = document.getElementsByClassName("goodiesItem");
    let i;
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }

}

let pastColorIndex = null;
function applyGoodie(index){
    console.log("Applying... showing state: "+document.getElementById("goodie_"+index).showing);
    if(document.getElementById("goodie_"+index).showing == false || document.getElementById("goodie_"+index).showing === undefined){
        if(scorePrice[index]["type"] == "color"){
            
            
            document.getElementById("startQs").style.color = scorePrice[index]["contrast"];
            if(scorePrice[index]["shade"] == "white"){
                document.body.style.backgroundImage = "url('/assets/startBack.png')";
                document.body.style.backgroundSize = "cover";
                document.getElementById("startQs").style.backgroundImage = "none";
                document.getElementById("startQs").style.backgroundColor = "white";
                
            }
            else{
                document.body.style.backgroundColor = scorePrice[index]["shade"];
                document.body.style.backgroundImage = "none";
            }



            document.getElementById("goodie_"+index).style.border = "2px solid black";
    
            if(pastColorIndex == null){
                pastColorIndex=index;
                activeGoodies = index;
                localStorage.setItem("activeGoodies", String(activeGoodies));
            }
            
            else{
                document.getElementById("goodie_"+pastColorIndex).showing = false;
                if(pastColorIndex != index){
                    document.getElementById("goodie_"+pastColorIndex).style.border = "initial";
                }

                activeGoodies = index;
                localStorage.setItem("activeGoodies", String(activeGoodies));



                pastColorIndex = index;
            }

        }
        else{

            if(document.getElementById("scene_"+index) == null){
                
                var newScene = document.createElement("img");
                newScene.src = scorePrice[index]["rep"];
                newScene.className = "Escenario";
                newScene.id = "scene_"+index;

                document.getElementById("goodiesRep").appendChild(newScene);
            }
            else{
                document.getElementById("scene_"+index).style.display = "inline";
            }
        }
        document.getElementById("goodie_"+index).showing = true;


    }
    else{
        if(scorePrice[index]["type"] == "color"){
            document.body.style.backgroundColor = "#101015";
            activeGoodies = -1;
            localStorage.setItem("activeGoodies", String(activeGoodies));
            document.getElementById("goodie_"+index).style.border = "initial";
            
        }
        else if(scorePrice[index]["type"] == "escenario"){
            if(document.getElementById("scene_"+index) != null){
                document.getElementById("scene_"+index).style.display = "none";
            }
        }

        document.getElementById("goodie_"+index).showing = false;

        

    }
}
let selectedButton = subject;
document.getElementById(subject+"Selector").style.filter = "brightness(60%)";

document.getElementById("mathSelector").onclick = function(){
    document.getElementById(subject+"Selector").style.filter = "brightness(100%)";
    subject = "math";
    localStorage.setItem("subject", subject);
    selectedList = mathSelector;
    renderQue();
    document.getElementById(subject+"Selector").style.filter = "brightness(60%)";

}
document.getElementById("scienceSelector").onclick = function(){
    document.getElementById(subject+"Selector").style.filter = "brightness(100%)";
    subject = "science";
    localStorage.setItem("subject", subject);
    selectedList = scienceSelector;
    renderQue();
    document.getElementById(subject+"Selector").style.filter = "brightness(60%)";

}
document.getElementById("mixtSelector").onclick = function(){
    document.getElementById(subject+"Selector").style.filter = "brightness(100%)";
    subject = "mixt";
    localStorage.setItem("subject", subject);
    selectedList = mixtSelector;
    renderQue();
    document.getElementById(subject+"Selector").style.filter = "brightness(60%)";

}


















