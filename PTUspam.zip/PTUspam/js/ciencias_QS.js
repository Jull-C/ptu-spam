export let scienceSelector = [
    {
        "statement": "Si una célula es puesta en un medio hipotónico, ingresara gran cantidad de agua y se diluirá su contenido. En las células animales esto podría generar la ruptura de la célula, en cambio en las células vegetales nunca llega a romperse.<br/>¿Cuál es la razón por la que no estalla la célula vegetal?",
        "answer_1": "Por las vacuolas que almacenan gran cantidad de agua.",
        "answer_2": "Por los cloroplastos que requieren continuamente agua para la fotosíntesis.",
        "answer_3": "Por la pared vegetal que ejerce una fuerza contraria a la fuerza de ingreso del agua",
        "answer_4": "Por la membrana plasmática que es más permeable a la entrada y salida de agua",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿En qué etapa del ciclo celular se produce la máxima compactación de la cromatina?",
        "answer_1": "Interfase",
        "answer_2": "Metafase",
        "answer_3": "Telofase",
        "answer_4": "G1",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "El cigoto, producto de la fecundación, es implantado en el endometrio:",
        "answer_1": "Los dos primeros días después de la fecundación",
        "answer_2": "La tercera semana después de la fecundación",
        "answer_3": "Las 24 horas después de la fecundación",
        "answer_4": "Entre el séptimo y undécimo día después de la fecundación",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "En el caso de un rasgo fenotípico que se hereda según el modelo mendeliano,la proporción fenotípica que se observará en la descendencia de un homocigoto dominante: <br/><br/>I) es independiente del genotipo del otro progenitor.<br/>II) es impredecible.<br/>III)dependerá del genotipo del otro progenitor.",
        "answer_1": "Solo I.",
        "answer_2": "Solo II.",
        "answer_3": "Solo I y III.",
        "answer_4": "I, II y III.",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "Las rémoras son peces que usualmente viven relacionándose con especies más grandes, como tiburones. Esto no afecta a los tiburones, pero les entrega protección, alimento y transporte a las rémoras. ¿Cómo podría definirse la relación entre rémoras y tiburones?",
        "answer_1": "Comensalismo",
        "answer_2": "Simbiosis",
        "answer_3": "Competencia",
        "answer_4": "Parasitismo",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "Una planta que se encuentra en condiciones óptimas para desarrollar fotosíntesis, deja de realizarla debido a que sus estomas se encuentran cerrados. Si se desea realizar un análisis a las variables que pueden encontrarse involucradas en este fenómeno, ¿cuál de ellas debiese descartar antes de llevarlo a cabo?",
        "answer_1": "Cantidad de luz.",
        "answer_2": "Cantidad de agua.",
        "answer_3": "Temperatura.",
        "answer_4": "Concentración de sales del suelo.",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "El sonido se puede:<br/><br/>I) Refractar<br/>II) Difractar<br/>III) Reflejar<br/>Es(son) correctas:",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo II y III",
        "answer_4": "I, II y III",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Con respecto a la sombra y penumbra, se afirma que:<br/><br/>I) si la fuente es puntual, se forma una sombra de un cuerpo opaco.<br/>II) la formación de sombra y penumbra depende de la distancia entre la fuente de luz y el cuerpo opaco.<br/>III) se forman porque los rayos luminosos se mueven en línea recta.<br/>Es (son) correcta(s):",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Un objeto posee una masa inicial m y una rapidez v, pero en una situación posterior su masa aumenta al triple y su rapidez disminuye a la mitad. La razón entre el momento lineal inicial y final es:",
        "answer_1": "$$\\frac{3}{2}$$",
        "answer_2": "$$\\frac{2}{3}$$",
        "answer_3": "$$\\frac{9}{4}$$",
        "answer_4": "$$\\frac{4}{9}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Dos patinadores están sobre la superficie de un lago congelado, donde se considera el roce nulo. Si el primer patinador empuja al segundo patinador con una fuerza , estando ambos inicialmente en reposo. Dado lo anterior, es correcto afirmar que:",
        "answer_1": "Sólo el segundo se mueve.",
        "answer_2": "Ambos se mueven en el mismo sentido",
        "answer_3": "Los dos quedan en reposo.",
        "answer_4": "Ambos se mueven en sentido opuesto.",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "La temperatura de un cuerpo aumenta hasta los 10°C. Entonces en el cuerpo tenemos:",
        "answer_1": "un calor igual a 10 calorías.",
        "answer_2": "un aumento de la energía cinética de las moléculas.",
        "answer_3": "una disminución de la energía cinética.",
        "answer_4": "un aumento en la capacidad calórica.",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Si un ión de carga $$+3$$ tiene la configuración $$1s^{2}$$ $$2s^{2}$$ $$2p^{4}$$, el número atómico que originó el ión es:",
        "answer_1": "13",
        "answer_2": "8",
        "answer_3": "11",
        "answer_4": "4",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál(es) de las siguientes moléculas posee(n) un carbono quiral?<br/><br/>I) Etanamida<br/>II) Propanamida<br/>III) Ácido-2-aminobutanoico",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál es el número de isómeros estructurales de la especie química de fórmula molecular $$C_2H_4Br_2$$?",
        "answer_1": "1",
        "answer_2": "2",
        "answer_3": "3",
        "answer_4": "4",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "¿Cuántos gramos de NaCl (Masa molar = 58 g/mol) se necesitan para 100 mL de solución a 0,3 M?",
        "answer_1": "1,74 gramos",
        "answer_2": "0,174 gramos",
        "answer_3": "17,4 gramos",
        "answer_4": "174 gramos",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "El agua de mar tiene:",
        "answer_1": "mayor presión de vapor que el agua potable.",
        "answer_2": "mayor densidad que el agua dulce.",
        "answer_3": "el mismo punto de ebullición del agua pura.",
        "answer_4": "un punto de congelación mayor que el agua pura.",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "¿Cómo se denomina el proceso mediante el cual, el agua pasa desde una solución diluida a otra más concentrada?",
        "answer_1": "Osmosis",
        "answer_2": "Dispersión",
        "answer_3": "Insaturación",
        "answer_4": "Homogenización",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "En relación a las propiedades coligativas se puede decir que:",
        "answer_1": "si se disuelve en agua un soluto volátil, aumenta su temperatura de ebullición.",
        "answer_2": "dependen solo de la concentración de soluto en la disolución y no de la naturaleza de este.",
        "answer_3": "se estudian disoluciones concentradas, cuyas concentraciones superan los 0,2M.",
        "answer_4": "al agregar un soluto no volátil a un disolvente puro, la presión de vapor que se obtiene es mayor que la original.",
        "correct": "ansB",
        "opDiv": "opDivB"
    }



];




export let mathSelector = [
    {
        "statement": "$$(\\sqrt[3]{\\sqrt{2^5}})^4=$$",
        "answer_1": "$$\\sqrt[10]{3^{2}}$$",
        "answer_2": "$$\\sqrt[2]{10^{3}}$$",
        "answer_3": "$$\\sqrt[3]{2^{10}}$$",
        "answer_4": "$$\\sqrt[10]{2^{3}}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) Dos polígonos semejantes tienen distinto perímetro.<br/>II) Dos cuadrados que tienen distinta área son congruentes.<br/>III) Los triángulos que se generan al trazar la diagonal de un cuadrado son congruentes.",
        "answer_1": "Sólo I",
        "answer_2": "Sólo II",
        "answer_3": "Sólo I y III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál es la probabilidad de que al lanzar un dado 4 veces, no se obtenga un 6?",
        "answer_1": "$$\\frac{1}{1296}$$",
        "answer_2": "$$\\frac{10}{3}$$",
        "answer_3": "$$\\frac{2}{3}$$",
        "answer_4": "$$\\frac{625}{1296}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Si se elige al azar un número de entre los primeros 20 números enteros positivos, ¿cuál es la probabilidad de que sea un número primo o un número divisor de 24?",
        "answer_1": "$$\\frac{18}{20}$$",
        "answer_2": "$$\\frac{14}{20}$$",
        "answer_3": "$$\\frac{16}{20}$$",
        "answer_4": "$$\\frac{13}{20}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Al lanzar dos monedas al mismo tiempo, ¿cuál es la probabilidad de obtener dos caras?",
        "answer_1": "$$\\frac{1}{2}$$",
        "answer_2": "$$\\frac{1}{3}$$",
        "answer_3": "$$\\frac{1}{4}$$",
        "answer_4": "$$\\frac{2}{3}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Si se lanzan 5 monedas al aire, ¿cuál es la probabilidad de obtener cara, sello, sello, cara y cara, en ese orden?",
        "answer_1": "$$\\frac{1}{64}$$",
        "answer_2": "$$\\frac{1}{2}$$",
        "answer_3": "$$\\frac{1}{32}$$",
        "answer_4": "$$\\frac{5}{2}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Al lanzar 2 dados de seis caras no cargados, ¿cuál es la probabilidad de que el producto de sus puntuaciones sea un número impar?",
        "answer_1": "$$\\frac{1}{2}$$",
        "answer_2": "$$\\frac{1}{4}$$",
        "answer_3": "$$\\frac{3}{4}$$",
        "answer_4": "$$\\frac{1}{3}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Si se lanza una moneda tres veces, ¿cuál es la probabilidad de que las tres veces salga lo mismo?",
        "answer_1": "$$\\frac{1}{8}$$",
        "answer_2": "$$\\frac{1}{4}$$",
        "answer_3": "$$\\frac{3}{8}$$",
        "answer_4": "$$\\frac{1}{2}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Pablo quiere tomar un bus que lo lleve al sur, para esto tiene 3 compañías de buses, donde cada una de ellas tiene 2 opciones de asiento, además debe escoger si viajar en la mañana o en la tarde. ¿Cuántas opciones de combinaciones totales posee para escoger como viajar al sur?",
        "answer_1": "3",
        "answer_2": "6",
        "answer_3": "9",
        "answer_4": "12",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "La tabla expuesta muestra la cantidad de grupos musicales favoritos que tienen los estudiantes de un curso.<br/>Podemos determinar la cantidad de estudiantes del curso si:<br/><br/>$$(1)a+b=14$$<br/>$$(2)y=a$$ y $$x=b$$",
        "answer_1": "(1) por sí sola",
        "answer_2": "(2) por sí sola",
        "answer_3": "Ambas juntas, (1) y (2)",
        "answer_4": "Cada una por sí sola, (1) o (2)",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_01.png"
    },//FROM HERE
    {
        "statement": "$$\\log_{3\\sqrt{3}}\\left(\\dfrac{1}{9}\\sqrt{3}\\right)$$",
        "answer_1": "-2",
        "answer_2": "-1",
        "answer_3": "0",
        "answer_4": "1",
        "correct": "ansB",
        "opDiv": "opDivB",
        
    },
    {
        "statement": "Dado que log ( 5$$^{x}$$ · 2$$^{x}$$ ) = 2, entonces x =",
        "answer_1": "0",
        "answer_2": "1",
        "answer_3": "2",
        "answer_4": "5",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Un científico escribe un artículo para una revista científica, como parte de la información indica que los glóbulos rojos humanos pueden llegar a medir $$0,000008$$ metros. ¿De qué otro modo se puede representar la longitud de un glóbulo rojo humano?",
        "answer_1": "$$10^{-8} [m]$$",
        "answer_2": "$$8 \\cdot 10^{6}[m]$$",
        "answer_3": "$$8 \\cdot 10^{-6}[m]$$",
        "answer_4": "$$8 \\cdot 10^{-7}[m]$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "La expresión $$(m + 5)(x + 1) + (m + 5)(2x + 1) + 3m + 15$$ es equivalente a:",
        "answer_1": "$$(m + 5)(3x + 2) + 3(m + 5)$$",
        "answer_2": "$$(m + 5)(3x + 5)$$",
        "answer_3": "$$(m + 5)(x + 1)(2x + 4)$$",
        "answer_4": "$$(m + 5)(3x + 2)(3m + 15)$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        
    },
    {
        "statement": "¿Para qué valores de a y b el sistema de ecuaciones $$\\begin{array}{lc|}x+by=-2\\\\ax+y=\\displaystyle\\frac{1}{2}\\\\ \\hline\\end{array}$$ no tiene solución?",
        "answer_1": "a = $$\\dfrac{1}{5}$$ y b = 5",
        "answer_2": "a = 1 y b = $$\\dfrac{2}{5}$$",
        "answer_3": "a = $$\\dfrac{1}{3}$$ y b = -3",
        "answer_4": "a = -1 y b = 1",
        "correct": "ansA",
        "opDiv": "opDivA",
        
    },
    {
        "statement": "¿Cuál(es) de las siguientes funciones corresponde(n) a función(es) potencia?<br/><br/>I. f(x) = 3$$^{2}$$<br/>II. h(x) = ($$\\sqrt{2})^{2}$$<br/>III. p(x) = x$$^{3}$$",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "Solo I y II",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "¿Para qué valor de $$x$$ la expresión $$3(x+1)-2(x-4)$$ es igual a $$3$$?",
        "answer_1": "-8",
        "answer_2": "-7",
        "answer_3": "-5",
        "answer_4": "5",
        "correct": "ansA",
        "opDiv": "opDivA",
        
    },
    {
        "statement": "Si $$x - y > 2y$$, entonces se deduce que:",
        "answer_1": "$$x + y > 0$$",
        "answer_2": "$$x + y < 0$$",
        "answer_3": "$$x - 3y > 0$$",
        "answer_4": "$$3y - x > 0$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Si $$x$$,$$y$$ y $$z$$ son variables, ¿cuál(es) de los siguientes polinomios es (son) homogéneo(s)?<br/><br/>I)$$2x^{3}+3x^{2}y-2xy^{2}+y^{3}$$<br/>II)$$x^{2}+2xy+y^{2}$$<br/>III)$$x^{2}+y^{3}+z^{4}$$",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y II",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "La altura respecto de la hipotenusa de un triángulo rectángulo divide a ésta en dos segmentos cuyas longitudes son entre sí como 1 : 9. Si la longitud de la altura es 9 cm, entonces la longitud de la hipotenusa es :",
        "answer_1": "10 cm",
        "answer_2": "20 cm",
        "answer_3": "30 cm",
        "answer_4": "40 cm",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "En el $$\\Delta\\text{ABC}$$ de la figura adjunta, D pertenece a $$\\overline{\\text{AB}}$$. ¿Cuál es la medida del trazo $$\\overline{\\text{CD}}$$?",
        "answer_1": "$$\\displaystyle\\frac{\\sqrt{11}}{2}$$",
        "answer_2": "$$\\displaystyle\\frac{9}{5}$$",
        "answer_3": "$$\\displaystyle\\frac{12}{5}$$",
        "answer_4": "$$\\displaystyle\\frac{144}{25}$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_01.png"
        
    },
    {
        "statement": "El triángulo $$\\Delta\\text{ABC}$$ es equilátero de área $$12 \\text{ cm}^{2}$$. $$M$$ y $$N$$ son puntos medios de los lados $$\\overline{\\text{BC}}$$ y $$\\overline{\\text{AC}}$$ respectivamente. Si $$\\overline{\\text{AM}}$$  y  $$\\overline{\\text{BN}}$$ se intersectan en el punto $$E$$, ¿cuál es el área del triángulo $$\\Delta\\text{ABE}$$?",
        "answer_1": "$$2 \\text{ cm}^{2}$$",
        "answer_2": "$$4 \\text{ cm}^{2}$$",
        "answer_3": "$$4,5 \\text{ cm}^{2}$$",
        "answer_4": "$$6 \\text{ cm}^{2}$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Geo_02.png"
        
    },
    {
        "statement": "Una ruleta circular ha sido dividida en 8 partes iguales, tal como se muestra en la figura. Al hacer girar la ruleta en torno a su centro, ¿cuál es la probabilidad de que la flecha apunte a una zona gris o a la zona del número 2, al terminar de girar?",
        "answer_1": "$$\\displaystyle\\frac{1}{8}$$",
        "answer_2": "$$\\displaystyle\\frac{5}{8}$$",
        "answer_3": "$$\\displaystyle\\frac{2}{3}$$",
        "answer_4": "$$\\displaystyle\\frac{7}{8}$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Prob_02.png"
        
    },
    {
        "statement": "Dado el siguiente conjunto de datos: 2; 5; 9; 3; 13; 10; 11; 6; 7. ¿Cuál es el valor del tercer cuartil?",
        "answer_1": "4",
        "answer_2": "5",
        "answer_3": "7",
        "answer_4": "10",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Se sabe que en una muestra la mediana es 7. Un dato de la muestra, cuyo valor es 12, se debe encontrar necesariamente en el:",
        "answer_1": "primer cuartil.",
        "answer_2": "segundo o tercer cuartil.",
        "answer_3": "tercer cuartil.",
        "answer_4": "tercer o cuarto cuartil.",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si $$x=\\displaystyle\\frac{\\log_{2}{\\displaystyle\\frac{1}{8}}}{\\log_{2}{16}}$$ e $$y=\\log_{3}{\\displaystyle\\frac{1}{27}}$$, el valor de $$\\displaystyle\\frac{2y}{x}$$ es:",
        "answer_1": "-3",
        "answer_2": "-1",
        "answer_3": "0",
        "answer_4": "8",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Javiera tiene que realizar un plano de manera que la escala a ocupar es $$1 : 50\\sqrt[3]{15}$$, esto significa que 1cm del plano equivale a $$50\\sqrt[3]{15}$$ cm de la realidad. Si la altura de la casa que quiere diseñar Javiera en la vida real debe medir $$3\\sqrt[3]{5}\\mbox{ m}$$, ¿cuánto debe medir la altura dibujada en su plano, expresada en cm?",
        "answer_1": "60cm",
        "answer_2": "$$20\\sqrt[3]{9}$$cm",
        "answer_3": "$$2\\sqrt[3]{9}$$cm",
        "answer_4": "$$\\displaystyle\\frac{\\sqrt[3]{3}}{60}$$cm",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "$$\\displaystyle\\frac{\\displaystyle\\log_{\\,2}{16}\\cdot\\log_{\\,3}{243}}{\\displaystyle\\log_{\\,5}{625}}=$$",
        "answer_1": "3",
        "answer_2": "4",
        "answer_3": "5",
        "answer_4": "7",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "Considere la función $$f$$ con dominio el conjunto de los números reales definida por $$\\text{f}(x) = -20 + 15x + 5 x^2$$. ¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s), con respecto a $$f$$?<br/><br/>I) Su gráfico intersecta al eje $$x$$ en los puntos $$(-4,0)$$ y $$(1,0)$$.<br/>II) Su gráfico tiene como eje de simetría a la recta $$x= -\\dfrac{3}{2}$$.<br/>III) Su valor máximo es $$-\\dfrac{25}{4}$$.",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y II",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Si el costo de mantención de una empresa se determina con la función $$f( x ) = -x^{2} + 2x + 8$$, donde x es el número de artículos diarios producidos. ¿ Cuál será el número de artículos diarios que se deben producir para obtener el máximo costo de mantención ?",
        "answer_1": "-1",
        "answer_2": "1",
        "answer_3": "2",
        "answer_4": "9",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El máximo valor que alcanza la función $$f(x)=-x^{2}+4x+5$$ es:",
        "answer_1": "3",
        "answer_2": "6",
        "answer_3": "9",
        "answer_4": "10",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "Dadas las expresiones $$x-y = z^{a}$$ y $$x+y=a^{z}$$, el valor de $$x^{2}-y^{2}$$ es:",
        "answer_1": "$$a^{2z}$$",
        "answer_2": "$$z^{2a}$$",
        "answer_3": "$$z^{a}\\cdot a^{z}$$",
        "answer_4": "$$za^{z+a}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": " ¿Cuál es la función inversa de la función f(x) = -5x + 1?",
        "answer_1": "f$$^{-1}$$(x) = $$\\dfrac{-x+1}{5}$$",
        "answer_2": "f$$^{-1}$$(x) = $$\\dfrac{x-1}{5}$$",
        "answer_3": "f$$^{-1}$$(x) = $$5x-1$$",
        "answer_4": "f$$^{-1}$$(x) = $$-\\dfrac{x}{5}+1$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si $$\\sqrt{x+5}=3$$, entonces $$3x$$ es igual a:",
        "answer_1": "4",
        "answer_2": "8",
        "answer_3": "9",
        "answer_4": "12",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "En la figura $$\\overline{\\text{CD}}=6$$cm  y $$\\overline{\\text{AD}}=3$$cm. ¿Cuál es el área del triángulo $$ABC$$?",
        "answer_1": "$$12\\ {cm}^2$$",
        "answer_2": "$$15\\ {cm}^2$$",
        "answer_3": "$$18\\ {cm}^2$$",
        "answer_4": "$$45\\ {cm}^2$$",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Geo_03.png"
        
    },
    {
        "statement": "Las coordenadas de los puntos que forman el cuadrado ABCD son $$\\mbox{A}(0,0)$$; $$\\mbox{B}(2,0)$$; $$\\mbox{C}(2,x)$$ y $$\\mbox{D}(y,2)$$. ¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) La distancia entre B y D es 3 unidades.<br/>II) La distancia entre A y C es $$2\\sqrt{2}$$ unidades.<br/>III) Los valores de $$x$$ e $$y$$ son 2 y 0 respectivamente.",
        "answer_1": "Solo II",
        "answer_2": "Solo III",
        "answer_3": "Solo I y III",
        "answer_4": "Solo II y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        
    },
    {
        "statement": "En el triángulo ABC de la figura adjunta, $$\\overline{AD}$$ = m ,$$\\overline{DB}$$  = n y $$\\overline{BC}$$ = a . El segmento AC es :",
        "answer_1": "$$\\dfrac{an}{m}$$",
        "answer_2": "$$\\dfrac{am}{n}$$",
        "answer_3": "$$\\dfrac{mn}{a}$$",
        "answer_4": "$$\\dfrac{n}{am}$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_04.png"
        
    },
    {
        "statement": "Si se lanzan 5 monedas al aire, ¿cuál es la probabilidad de obtener cara, sello, sello, cara y cara, en ese orden?",
        "answer_1": "$$\\displaystyle\\frac{1}{64}$$",
        "answer_2": "$$\\displaystyle\\frac{1}{32}$$",
        "answer_3": "$$\\displaystyle\\frac{1}{2}$$",
        "answer_4": "$$\\displaystyle\\frac{5}{2}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "La siguiente tabla muestra la distribución de los pesos, en kilogramos, de todos los empleados de una empresa.<br/>De acuerdo a la información de la tabla, ¿cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) Hay 58 empleados en total en la empresa.<br/>II) Hay 18 personas que pesan 90 kg o 100 kg.<br/>III) El rango de la distribución es 10 kg.",
        "answer_1": "Solo II",
        "answer_2": "Solo III",
        "answer_3": "Solo I y II",
        "answer_4": "Solo I y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_03.png"
        
    },
    {
        "statement": "¿Cuál es el valor del tercer cuartil de los datos?",
        "answer_1": "2",
        "answer_2": "3",
        "answer_3": "4",
        "answer_4": "5",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Prob_04.png"
        
    },
    {
        "statement": "¿Cuál es el resultado de $$(0,3)^9 \\cdot (0,3)^3$$ escrito como una sola potencia?",
        "answer_1": "$$(0,3)^3$$",
        "answer_2": "$$(0,3)^6$$",
        "answer_3": "$$(0,3)^{12}$$",
        "answer_4": "$$(0,3)^{21}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "El valor de $$\\dfrac{-3^4}{(-5)^2}$$ es:",
        "answer_1": "$$\\dfrac{-81}{25}$$",
        "answer_2": "$$\\dfrac{-6}{5}$$",
        "answer_3": "$$\\dfrac{6}{5}$$",
        "answer_4": "$$\\dfrac{81}{25}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Una mezcla de $$7\\frac{1}{2}$$ litros de agua y leche tiene un $$60\\%$$ de leche. Si se agrega $$1\\frac{1}{2}$$ litros de agua, ¿qué porcentaje de la nueva mezcla es leche?",
        "answer_1": "$$40\\%$$",
        "answer_2": "$$50\\%$$",
        "answer_3": "$$63\\%$$",
        "answer_4": "$$64\\%$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "$$\\displaystyle\\frac{a^{3x+2}\\ \\cdot \\ b^{3x+2}}{a}\\div \\displaystyle\\frac{{(ba)}^{3x+2}}{b}=$$",
        "answer_1": "$$\\displaystyle\\frac{b}{a}$$",
        "answer_2": "$$\\displaystyle\\frac{-b}{a}$$",
        "answer_3": "$$\\displaystyle\\frac{a}{b}$$",
        "answer_4": "$$-\\displaystyle\\frac{a}{b}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "El par solución del sistema de ecuaciones<br/><br/>$$\\begin{array}{c|}3x+4=y\\2y-8=4x\\ \\hline\\end{array}$$<br/> es:",
        "answer_1": "$$(0,3)$$",
        "answer_2": "$$(1,3)$$",
        "answer_3": "$$(0,4)$$",
        "answer_4": "$$(0,-4)$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "El área del triángulo mostrado a continuación es igual a $$90[u^2]$$. ¿Cuál es la medida de la base?",
        "answer_1": "$$9[u]$$",
        "answer_2": "$$12[u]$$",
        "answer_3": "$$18[u]$$",
        "answer_4": "$$15[u]$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_05.png"
        
    },
    {
        "statement": "Al expresar gráficamente y como intervalo el conjunto solución del sistema<br/><br/>$$5x-4>7x-16$$<br/>$$8-7x<16-15x$$<br/><br/>se obtiene:",
        "answer_1": "$$]-\\infty,1[$$",
        "answer_2": "$$]-\\infty,1]$$",
        "answer_3": "$$]1,+\\infty[$$",
        "answer_4": "$$[1,+\\infty[$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Sea la parábola cuya función es $$f( x ) = 5x^{2} + 5x + k$$. ¿ Para qué valor de k la parábola intersecta en un solo punto al eje de las abscisas?",
        "answer_1": "$$\\dfrac{5}{4}$$",
        "answer_2": "$$\\dfrac{1}{2}$$",
        "answer_3": "$$-\\dfrac{1}{2}$$",
        "answer_4": "$$-\\dfrac{5}{4}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Se define una función f cuyo dominio es $$\\mathbb{R}^{+}_{0}$$. La expresión que define a la función f es f(x) = $$\\sqrt{2x}$$. ¿Cuál es la expresión de la función f$$^{-1}$$(x)?",
        "answer_1": "f$$^{-1}$$(x) = $$\\dfrac{1}{2}$$ x$$^2$$",
        "answer_2": "f$$^{-1}$$(x) = $$\\dfrac{1}{4}$$ x$$^2$$",
        "answer_3": "f$$^{-1}$$(x) = 2x$$^2$$",
        "answer_4": "f$$^{-1}$$(x) = 4x$$^2$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Las rectas cuyas ecuaciones son $$x + 2y = 3$$ y $$x – ay – 4 = 0$$ son perpendiculares. Entonces, ¿cuál es el valor de $$a$$?",
        "answer_1": "$$\\dfrac{1}{2}$$",
        "answer_2": "$$\\dfrac{1}{4}$$",
        "answer_3": "$$-\\dfrac{1}{2}$$",
        "answer_4": "$$-\\dfrac{1}{4}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si al punto $$\\mbox{P}=(1, 3)$$ se le aplica una rotación de $$180^{\\circ}$$ en torno al origen del plano cartesiano, ¿cuáles serán las nuevas coordenadas del punto resultante?",
        "answer_1": "$$(-1, -3)$$",
        "answer_2": "$$(-1, 3)$$",
        "answer_3": "$$(1, -3)$$",
        "answer_4": "$$(2, -6)$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "En la figura adjunta, el Δ ABC es rectángulo en C, D y E son puntos medios de $$\\overline{AB}$$ y $$\\overline{CA}$$, respectivamente y $$\\overline{AC}$$ = $$\\overline{BC}$$ = 2 cm. ¿ Cuál(es) de las siguientes proposiciones es(son) verdadera(s)? <br/><br/>I) El triángulo CDE es isóceles<br/>II) El área del triángulo CDE es 0,5 cm$$^{2}$$<br/>III) El perímetro del triángulo CDE es (2 + $$\\sqrt{2}$$)cm",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "I, II y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Geo_06.png"
        
    },
    {
        "statement": "En la ojiva de la figura adjunta se muestra la distribución de los puntajes de $$300$$ estudiantes en una prueba, donde los intervalos del gráfico son de la forma $$[a,b[$$ excepto el último que es de la forma $$[c,d]$$.",
        "answer_1": "El intervalo modal es $$\\left[750,850\\right]$$.",
        "answer_2": "Solo $$49$$ estudiantes obtuvieron menos de $$650$$ puntos.",
        "answer_3": "$$181$$ estudiantes obtiene más de $$650$$ puntos.",
        "answer_4": "Un $$25\\%$$ de los estudiantes obtiene menos de $$550$$ puntos.",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_05.png"
        
    },
    {
        "statement": "Respecto a una distribución estadística, ¿cuál de las siguientes afirmaciones es falsa?",
        "answer_1": "La mediana es el segundo cuartil.",
        "answer_2": "El segundo cuartil corresponde al percentil 50.",
        "answer_3": "El rango intercuartil corresponde a la diferencia entre el primer y tercer cuartil.",
        "answer_4": "El decil 75, corresponde al tercer cuartil y a su vez al percentil 75.",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Las autoridades de una ciudad, preocupadas por las altas tasas de alcoholismo, decidieron hacer una medición de la cantidad de vasos de alcohol que consume una persona por semana, obteniéndose los resultados mostrados en la siguiente tabla:<br/><br/>¿En qué intervalo se encuentra el tercer cuartil de la distribución?",
        "answer_1": "$$11 - 20$$",
        "answer_2": "$$21 - 30$$",
        "answer_3": "$$31 - 40$$",
        "answer_4": "$$41 - 50$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Prob_06.png"
        
    },
    {
        "statement": "Al reducir al máximo $$\\displaystyle\\frac{\\sqrt{7+2\\sqrt{6}}}{\\sqrt{7-2\\sqrt{6}}}$$ se obtiene:",
        "answer_1": "$$7-\\sqrt{6}$$",
        "answer_2": "$$\\displaystyle\\frac{3\\sqrt{5}}{5}21 - 30$$",
        "answer_3": "$$\\displaystyle\\frac{7+\\sqrt{12}}{5}$$",
        "answer_4": "$$\\displaystyle\\frac{7+2\\sqrt{6}}{5}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "El valor de x en la ecuación 3 = 5$$^{x}$$ es :",
        "answer_1": "log 3 ∙ log 5",
        "answer_2": "$$\\dfrac{log 3}{log 5}$$",
        "answer_3": "1",
        "answer_4": "log 15",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "Si los catetos de un triángulo rectángulo se triplican, entonces, ¿cómo varía su hipotenusa?",
        "answer_1": "Es un 300$$\\%$$ de la original.",
        "answer_2": "Es un 600$$\\%$$ de la original.",
        "answer_3": "Es un 900$$\\%$$ de la original.",
        "answer_4": "Es un 90$$\\%$$ de la original.",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si $$f(x)=x^2-3$$ y $$h(z)=z+4$$, entonces el valor de $$3f(-1)+5h(2)$$ es:",
        "answer_1": "24",
        "answer_2": "36",
        "answer_3": "-6",
        "answer_4": "30",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "¿Cuántos números naturales cumplen la condición de que su décima parte es mayor o igual que su mitad disminuida en 2?",
        "answer_1": "2",
        "answer_2": "3",
        "answer_3": "4",
        "answer_4": "5",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si $$-6 \\geq 4t$$, entonces ¿cuáles son los valores de $$t$$?",
        "answer_1": "$$t \\geq -\\displaystyle \\frac{3}{2}$$",
        "answer_2": "$$t \\leq -\\displaystyle \\frac{3}{2}$$",
        "answer_3": "$$t < -\\displaystyle \\frac{3}{2}$$",
        "answer_4": "$$t \\leq -10$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El día lunes un artesano vendió $$15$$ aros y $$10$$ collares, obteniendo $$\\$90\\text{.}000$$ de recaudación entre ellos. El martes el artesano vendió $$6$$ aros y $$8$$ collares, recaudando entre ellos $$\\$60\\text{.}000$$. Si el artesano no cambió los precios de los aros y collares de un día a otro, ¿a qué valor está vendiendo cada collar?",
        "answer_1": "$$\\$2\\text{.}000$$",
        "answer_2": "$$\\$6\\text{.}000$$",
        "answer_3": "$$\\$2\\text{.}400$$",
        "answer_4": "$$\\$8\\text{.}000$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "Dada la ecuación $$(3m-1)x^2+4x-2=0$$, ¿qué condición debe cumplir m para que la ecuación NO tenga soluciones reales?",
        "answer_1": "$$m\\geq-\\dfrac{1}{3}$$",
        "answer_2": "$$m<-\\dfrac{1}{3}$$",
        "answer_3": "$$m<\\dfrac{1}{6}$$",
        "answer_4": "$$m<-\\dfrac{7}{6}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "La edad de Pedro es el doble de la edad de Ricardo, y la edad de Ximena es la mitad de la edad de Ricardo. Si la suma de sus edades es 63 años, ¿qué edad tiene Ximena??",
        "answer_1": "36 años",
        "answer_2": "24 años",
        "answer_3": "18 años",
        "answer_4": "9 años",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si al punto $$A(7, -13)$$ le aplicamos una simetría con respecto al eje $$y$$ y luego una respecto al eje $$x$$, se obtiene el punto:",
        "answer_1": "$$(-7,-13)$$",
        "answer_2": "$$(-7,13)$$",
        "answer_3": "$$(-13,7)$$",
        "answer_4": "$$(-13,-7)$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El punto medio entre dos puntos A y B es $$M(2,1)$$ y el vector director entre estos dos puntos es $$\\vec {d}=(4,-2)$$. Determinar los puntos A y B.",
        "answer_1": "A(0,2) y B(4,2)",
        "answer_2": "A(4,2) y B(4,0)",
        "answer_3": "A(4,0) y B(6,-2)",
        "answer_4": "A(0,2) y B(4,0)",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "El gobierno ha informado de un nuevo beneficio para el tratamiento de una enfermedad: la persona beneficiada deberá pagar solo el porcentaje correspondiente a los cuartiles sobre los cuales se encuentra. Por ejemplo, las personas pertenecientes al segundo cuartil pagan un $$50\\%$$ del tratamiento, correspondiente al porcentaje asociado al primer cuartil. Si una persona paga el $$50\\%$$ del tratamiento, ¿cuál es el cuartil al que pertenece?",
        "answer_1": "Primer cuartil",
        "answer_2": "Segundo cuartil",
        "answer_3": "Tercer cuartil",
        "answer_4": "Cuarto cuartil",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "En una urna hay $$3$$ bolas rojas numeradas del $$1$$ al $$3$$ y $$5$$ bolas amarillas numeradas del $$3$$ al $$7$$. Al extraer una bola al azar de la urna, ¿cuál es la probabilidad de sacar una bola roja o un número par?",
        "answer_1": "$$\\displaystyle \\frac{3}{8}$$",
        "answer_2": "$$\\displaystyle \\frac{6}{8}$$",
        "answer_3": "$$\\displaystyle \\frac{1}{2}$$",
        "answer_4": "$$\\displaystyle \\frac{5}{8}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Un naipe inglés tiene $$52$$ cartas repartidas equitativamente en cuatro pintas. Si te entregan tres cartas del naipe al azar, sin reposición, ¿cuál es la probabilidad de que las tres cartas sean un trío de ases?",
        "answer_1": "$$\\displaystyle\\frac{1}{4^3}$$",
        "answer_2": "$$\\displaystyle\\frac{1}{13^3}$$",
        "answer_3": "$$\\displaystyle\\frac{4\\cdot3\\cdot2}{52^3}$$",
        "answer_4": "$$\\displaystyle\\frac{4\\cdot3\\cdot2}{52\\cdot51\\cdot50}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    }
]





export let mixtSelector = [
    
    
    //MATH------------------------
    {
        "statement": "$$(\\sqrt[3]{\\sqrt{2^5}})^4=$$",
        "answer_1": "$$\\sqrt[10]{3^{2}}$$",
        "answer_2": "$$\\sqrt[2]{10^{3}}$$",
        "answer_3": "$$\\sqrt[3]{2^{10}}$$",
        "answer_4": "$$\\sqrt[10]{2^{3}}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) Dos polígonos semejantes tienen distinto perímetro.<br/>II) Dos cuadrados que tienen distinta área son congruentes.<br/>III) Los triángulos que se generan al trazar la diagonal de un cuadrado son congruentes.",
        "answer_1": "Sólo I",
        "answer_2": "Sólo II",
        "answer_3": "Sólo I y III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },//from here
    {
        "statement": "¿Cuál es la probabilidad de que al lanzar un dado 4 veces, no se obtenga un 6?",
        "answer_1": "$$\\frac{1}{1296}$$",
        "answer_2": "$$\\frac{10}{3}$$",
        "answer_3": "$$\\frac{2}{3}$$",
        "answer_4": "$$\\frac{625}{1296}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Si se elige al azar un número de entre los primeros 20 números enteros positivos, ¿cuál es la probabilidad de que sea un número primo o un número divisor de 24?",
        "answer_1": "$$\\frac{18}{20}$$",
        "answer_2": "$$\\frac{14}{20}$$",
        "answer_3": "$$\\frac{16}{20}$$",
        "answer_4": "$$\\frac{13}{20}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Al lanzar dos monedas al mismo tiempo, ¿cuál es la probabilidad de obtener dos caras?",
        "answer_1": "$$\\frac{1}{2}$$",
        "answer_2": "$$\\frac{1}{3}$$",
        "answer_3": "$$\\frac{1}{4}$$",
        "answer_4": "$$\\frac{2}{3}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Si se lanzan 5 monedas al aire, ¿cuál es la probabilidad de obtener cara, sello, sello, cara y cara, en ese orden?",
        "answer_1": "$$\\frac{1}{64}$$",
        "answer_2": "$$\\frac{1}{2}$$",
        "answer_3": "$$\\frac{1}{32}$$",
        "answer_4": "$$\\frac{5}{2}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Al lanzar 2 dados de seis caras no cargados, ¿cuál es la probabilidad de que el producto de sus puntuaciones sea un número impar?",
        "answer_1": "$$\\frac{1}{2}$$",
        "answer_2": "$$\\frac{1}{4}$$",
        "answer_3": "$$\\frac{3}{4}$$",
        "answer_4": "$$\\frac{1}{3}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Si se lanza una moneda tres veces, ¿cuál es la probabilidad de que las tres veces salga lo mismo?",
        "answer_1": "$$\\frac{1}{8}$$",
        "answer_2": "$$\\frac{1}{4}$$",
        "answer_3": "$$\\frac{3}{8}$$",
        "answer_4": "$$\\frac{1}{2}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Pablo quiere tomar un bus que lo lleve al sur, para esto tiene 3 compañías de buses, donde cada una de ellas tiene 2 opciones de asiento, además debe escoger si viajar en la mañana o en la tarde. ¿Cuántas opciones de combinaciones totales posee para escoger como viajar al sur?",
        "answer_1": "3",
        "answer_2": "6",
        "answer_3": "9",
        "answer_4": "12",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "La tabla expuesta muestra la cantidad de grupos musicales favoritos que tienen los estudiantes de un curso.<br/>Podemos determinar la cantidad de estudiantes del curso si:<br/><br/>$$(1)a+b=14$$<br/>$$(2)y=a$$ y $$x=b$$",
        "answer_1": "(1) por sí sola",
        "answer_2": "(2) por sí sola",
        "answer_3": "Ambas juntas, (1) y (2)",
        "answer_4": "Cada una por sí sola, (1) o (2)",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_01.png"
    },
    {
        "statement": "$$\\log_{3\\sqrt{3}}\\left(\\dfrac{1}{9}\\sqrt{3}\\right)$$",
        "answer_1": "-2",
        "answer_2": "-1",
        "answer_3": "0",
        "answer_4": "1",
        "correct": "ansB",
        "opDiv": "opDivB",
        
    },
    {
        "statement": "Dado que log ( 5$$^{x}$$ · 2$$^{x}$$ ) = 2, entonces x =",
        "answer_1": "0",
        "answer_2": "1",
        "answer_3": "2",
        "answer_4": "5",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Un científico escribe un artículo para una revista científica, como parte de la información indica que los glóbulos rojos humanos pueden llegar a medir $$0,000008$$ metros. ¿De qué otro modo se puede representar la longitud de un glóbulo rojo humano?",
        "answer_1": "$$10^{-8} [m]$$",
        "answer_2": "$$8 \\cdot 10^{6}[m]$$",
        "answer_3": "$$8 \\cdot 10^{-6}[m]$$",
        "answer_4": "$$8 \\cdot 10^{-7}[m]$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "La expresión $$(m + 5)(x + 1) + (m + 5)(2x + 1) + 3m + 15$$ es equivalente a:",
        "answer_1": "$$(m + 5)(3x + 2) + 3(m + 5)$$",
        "answer_2": "$$(m + 5)(3x + 5)$$",
        "answer_3": "$$(m + 5)(x + 1)(2x + 4)$$",
        "answer_4": "$$(m + 5)(3x + 2)(3m + 15)$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        
    },
    {
        "statement": "¿Para qué valores de a y b el sistema de ecuaciones $$\\begin{array}{lc|}x+by=-2\\\\ax+y=\\displaystyle\\frac{1}{2}\\\\ \\hline\\end{array}$$ no tiene solución?",
        "answer_1": "a = $$\\dfrac{1}{5}$$ y b = 5",
        "answer_2": "a = 1 y b = $$\\dfrac{2}{5}$$",
        "answer_3": "a = $$\\dfrac{1}{3}$$ y b = -3",
        "answer_4": "a = -1 y b = 1",
        "correct": "ansA",
        "opDiv": "opDivA",
        
    },
    {
        "statement": "¿Cuál(es) de las siguientes funciones corresponde(n) a función(es) potencia?<br/><br/>I. f(x) = 3$$^{2}$$<br/>II. h(x) = ($$\\sqrt{2})^{2}$$<br/>III. p(x) = x$$^{3}$$",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "Solo I y II",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "¿Para qué valor de $$x$$ la expresión $$3(x+1)-2(x-4)$$ es igual a $$3$$?",
        "answer_1": "-8",
        "answer_2": "-7",
        "answer_3": "-5",
        "answer_4": "5",
        "correct": "ansA",
        "opDiv": "opDivA",
        
    },
    {
        "statement": "Si $$x - y > 2y$$, entonces se deduce que:",
        "answer_1": "$$x + y > 0$$",
        "answer_2": "$$x + y < 0$$",
        "answer_3": "$$x - 3y > 0$$",
        "answer_4": "$$3y - x > 0$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Si $$x$$,$$y$$ y $$z$$ son variables, ¿cuál(es) de los siguientes polinomios es (son) homogéneo(s)?<br/><br/>I)$$2x^{3}+3x^{2}y-2xy^{2}+y^{3}$$<br/>II)$$x^{2}+2xy+y^{2}$$<br/>III)$$x^{2}+y^{3}+z^{4}$$",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y II",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "La altura respecto de la hipotenusa de un triángulo rectángulo divide a ésta en dos segmentos cuyas longitudes son entre sí como 1 : 9. Si la longitud de la altura es 9 cm, entonces la longitud de la hipotenusa es :",
        "answer_1": "10 cm",
        "answer_2": "20 cm",
        "answer_3": "30 cm",
        "answer_4": "40 cm",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "En el $$\\Delta\\text{ABC}$$ de la figura adjunta, D pertenece a $$\\overline{\\text{AB}}$$. ¿Cuál es la medida del trazo $$\\overline{\\text{CD}}$$?",
        "answer_1": "$$\\displaystyle\\frac{\\sqrt{11}}{2}$$",
        "answer_2": "$$\\displaystyle\\frac{9}{5}$$",
        "answer_3": "$$\\displaystyle\\frac{12}{5}$$",
        "answer_4": "$$\\displaystyle\\frac{144}{25}$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_01.png"
        
    },
    {
        "statement": "El triángulo $$\\Delta\\text{ABC}$$ es equilátero de área $$12 \\text{ cm}^{2}$$. $$M$$ y $$N$$ son puntos medios de los lados $$\\overline{\\text{BC}}$$ y $$\\overline{\\text{AC}}$$ respectivamente. Si $$\\overline{\\text{AM}}$$  y  $$\\overline{\\text{BN}}$$ se intersectan en el punto $$E$$, ¿cuál es el área del triángulo $$\\Delta\\text{ABE}$$?",
        "answer_1": "$$2 \\text{ cm}^{2}$$",
        "answer_2": "$$4 \\text{ cm}^{2}$$",
        "answer_3": "$$4,5 \\text{ cm}^{2}$$",
        "answer_4": "$$6 \\text{ cm}^{2}$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Geo_02.png"
        
    },
    {
        "statement": "Una ruleta circular ha sido dividida en 8 partes iguales, tal como se muestra en la figura. Al hacer girar la ruleta en torno a su centro, ¿cuál es la probabilidad de que la flecha apunte a una zona gris o a la zona del número 2, al terminar de girar?",
        "answer_1": "$$\\displaystyle\\frac{1}{8}$$",
        "answer_2": "$$\\displaystyle\\frac{5}{8}$$",
        "answer_3": "$$\\displaystyle\\frac{2}{3}$$",
        "answer_4": "$$\\displaystyle\\frac{7}{8}$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Prob_02.png"
        
    },
    {
        "statement": "Dado el siguiente conjunto de datos: 2; 5; 9; 3; 13; 10; 11; 6; 7. ¿Cuál es el valor del tercer cuartil?",
        "answer_1": "4",
        "answer_2": "5",
        "answer_3": "7",
        "answer_4": "10",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Se sabe que en una muestra la mediana es 7. Un dato de la muestra, cuyo valor es 12, se debe encontrar necesariamente en el:",
        "answer_1": "primer cuartil.",
        "answer_2": "segundo o tercer cuartil.",
        "answer_3": "tercer cuartil.",
        "answer_4": "tercer o cuarto cuartil.",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si $$x=\\displaystyle\\frac{\\log_{2}{\\displaystyle\\frac{1}{8}}}{\\log_{2}{16}}$$ e $$y=\\log_{3}{\\displaystyle\\frac{1}{27}}$$, el valor de $$\\displaystyle\\frac{2y}{x}$$ es:",
        "answer_1": "-3",
        "answer_2": "-1",
        "answer_3": "0",
        "answer_4": "8",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Javiera tiene que realizar un plano de manera que la escala a ocupar es $$1 : 50\\sqrt[3]{15}$$, esto significa que 1cm del plano equivale a $$50\\sqrt[3]{15}$$ cm de la realidad. Si la altura de la casa que quiere diseñar Javiera en la vida real debe medir $$3\\sqrt[3]{5}\\mbox{ m}$$, ¿cuánto debe medir la altura dibujada en su plano, expresada en cm?",
        "answer_1": "60cm",
        "answer_2": "$$20\\sqrt[3]{9}$$cm",
        "answer_3": "$$2\\sqrt[3]{9}$$cm",
        "answer_4": "$$\\displaystyle\\frac{\\sqrt[3]{3}}{60}$$cm",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "$$\\displaystyle\\frac{\\displaystyle\\log_{\\,2}{16}\\cdot\\log_{\\,3}{243}}{\\displaystyle\\log_{\\,5}{625}}=$$",
        "answer_1": "3",
        "answer_2": "4",
        "answer_3": "5",
        "answer_4": "7",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "Considere la función $$f$$ con dominio el conjunto de los números reales definida por $$\\text{f}(x) = -20 + 15x + 5 x^2$$. ¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s), con respecto a $$f$$?<br/><br/>I) Su gráfico intersecta al eje $$x$$ en los puntos $$(-4,0)$$ y $$(1,0)$$.<br/>II) Su gráfico tiene como eje de simetría a la recta $$x= -\\dfrac{3}{2}$$.<br/>III) Su valor máximo es $$-\\dfrac{25}{4}$$.",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y II",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC",
        
    },
    {
        "statement": "Si el costo de mantención de una empresa se determina con la función $$f( x ) = -x^{2} + 2x + 8$$, donde x es el número de artículos diarios producidos. ¿ Cuál será el número de artículos diarios que se deben producir para obtener el máximo costo de mantención ?",
        "answer_1": "-1",
        "answer_2": "1",
        "answer_3": "2",
        "answer_4": "9",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El máximo valor que alcanza la función $$f(x)=-x^{2}+4x+5$$ es:",
        "answer_1": "3",
        "answer_2": "6",
        "answer_3": "9",
        "answer_4": "10",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "Dadas las expresiones $$x-y = z^{a}$$ y $$x+y=a^{z}$$, el valor de $$x^{2}-y^{2}$$ es:",
        "answer_1": "$$a^{2z}$$",
        "answer_2": "$$z^{2a}$$",
        "answer_3": "$$z^{a}\\cdot a^{z}$$",
        "answer_4": "$$za^{z+a}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": " ¿Cuál es la función inversa de la función f(x) = -5x + 1?",
        "answer_1": "f$$^{-1}$$(x) = $$\\dfrac{-x+1}{5}$$",
        "answer_2": "f$$^{-1}$$(x) = $$\\dfrac{x-1}{5}$$",
        "answer_3": "f$$^{-1}$$(x) = $$5x-1$$",
        "answer_4": "f$$^{-1}$$(x) = $$-\\dfrac{x}{5}+1$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si $$\\sqrt{x+5}=3$$, entonces $$3x$$ es igual a:",
        "answer_1": "4",
        "answer_2": "8",
        "answer_3": "9",
        "answer_4": "12",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "En la figura $$\\overline{\\text{CD}}=6$$cm  y $$\\overline{\\text{AD}}=3$$cm. ¿Cuál es el área del triángulo $$ABC$$?",
        "answer_1": "$$12\\ {cm}^2$$",
        "answer_2": "$$15\\ {cm}^2$$",
        "answer_3": "$$18\\ {cm}^2$$",
        "answer_4": "$$45\\ {cm}^2$$",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Geo_03.png"
        
    },
    {
        "statement": "Las coordenadas de los puntos que forman el cuadrado ABCD son $$\\mbox{A}(0,0)$$; $$\\mbox{B}(2,0)$$; $$\\mbox{C}(2,x)$$ y $$\\mbox{D}(y,2)$$. ¿Cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) La distancia entre B y D es 3 unidades.<br/>II) La distancia entre A y C es $$2\\sqrt{2}$$ unidades.<br/>III) Los valores de $$x$$ e $$y$$ son 2 y 0 respectivamente.",
        "answer_1": "Solo II",
        "answer_2": "Solo III",
        "answer_3": "Solo I y III",
        "answer_4": "Solo II y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        
    },
    {
        "statement": "En el triángulo ABC de la figura adjunta, $$\\overline{AD}$$ = m ,$$\\overline{DB}$$  = n y $$\\overline{BC}$$ = a . El segmento AC es :",
        "answer_1": "$$\\dfrac{an}{m}$$",
        "answer_2": "$$\\dfrac{am}{n}$$",
        "answer_3": "$$\\dfrac{mn}{a}$$",
        "answer_4": "$$\\dfrac{n}{am}$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_04.png"
        
    },
    {
        "statement": "La siguiente tabla muestra la distribución de los pesos, en kilogramos, de todos los empleados de una empresa.<br/>De acuerdo a la información de la tabla, ¿cuál(es) de las siguientes afirmaciones es (son) verdadera(s)?<br/><br/>I) Hay 58 empleados en total en la empresa.<br/>II) Hay 18 personas que pesan 90 kg o 100 kg.<br/>III) El rango de la distribución es 10 kg.",
        "answer_1": "Solo II",
        "answer_2": "Solo III",
        "answer_3": "Solo I y II",
        "answer_4": "Solo I y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_03.png"
        
    },
    {
        "statement": "¿Cuál es el valor del tercer cuartil de los datos?",
        "answer_1": "2",
        "answer_2": "3",
        "answer_3": "4",
        "answer_4": "5",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Prob_04.png"
        
    },
    {
        "statement": "¿Cuál es el resultado de $$(0,3)^9 \\cdot (0,3)^3$$ escrito como una sola potencia?",
        "answer_1": "$$(0,3)^3$$",
        "answer_2": "$$(0,3)^6$$",
        "answer_3": "$$(0,3)^{12}$$",
        "answer_4": "$$(0,3)^{21}$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "El valor de $$\\dfrac{-3^4}{(-5)^2}$$ es:",
        "answer_1": "$$\\dfrac{-81}{25}$$",
        "answer_2": "$$\\dfrac{-6}{5}$$",
        "answer_3": "$$\\dfrac{6}{5}$$",
        "answer_4": "$$\\dfrac{81}{25}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Una mezcla de $$7\\frac{1}{2}$$ litros de agua y leche tiene un $$60\\%$$ de leche. Si se agrega $$1\\frac{1}{2}$$ litros de agua, ¿qué porcentaje de la nueva mezcla es leche?",
        "answer_1": "$$40\\%$$",
        "answer_2": "$$50\\%$$",
        "answer_3": "$$63\\%$$",
        "answer_4": "$$64\\%$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "$$\\displaystyle\\frac{a^{3x+2}\\ \\cdot \\ b^{3x+2}}{a}\\div \\displaystyle\\frac{{(ba)}^{3x+2}}{b}=$$",
        "answer_1": "$$\\displaystyle\\frac{b}{a}$$",
        "answer_2": "$$\\displaystyle\\frac{-b}{a}$$",
        "answer_3": "$$\\displaystyle\\frac{a}{b}$$",
        "answer_4": "$$-\\displaystyle\\frac{a}{b}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "El par solución del sistema de ecuaciones<br/><br/>$$\\begin{array}{c|}3x+4=y\\2y-8=4x\\ \\hline\\end{array}$$<br/> es:",
        "answer_1": "$$(0,3)$$",
        "answer_2": "$$(1,3)$$",
        "answer_3": "$$(0,4)$$",
        "answer_4": "$$(0,-4)$$",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "El área del triángulo mostrado a continuación es igual a $$90[u^2]$$. ¿Cuál es la medida de la base?",
        "answer_1": "$$9[u]$$",
        "answer_2": "$$12[u]$$",
        "answer_3": "$$18[u]$$",
        "answer_4": "$$15[u]$$",
        "correct": "ansC",
        "opDiv": "opDivC",
        "imagePath":"/assets/imgForQs/Geo_05.png"
        
    },
    {
        "statement": "Al expresar gráficamente y como intervalo el conjunto solución del sistema<br/><br/>$$5x-4>7x-16$$<br/>$$8-7x<16-15x$$<br/><br/>se obtiene:",
        "answer_1": "$$]-\\infty,1[$$",
        "answer_2": "$$]-\\infty,1]$$",
        "answer_3": "$$]1,+\\infty[$$",
        "answer_4": "$$[1,+\\infty[$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Sea la parábola cuya función es $$f( x ) = 5x^{2} + 5x + k$$. ¿ Para qué valor de k la parábola intersecta en un solo punto al eje de las abscisas?",
        "answer_1": "$$\\dfrac{5}{4}$$",
        "answer_2": "$$\\dfrac{1}{2}$$",
        "answer_3": "$$-\\dfrac{1}{2}$$",
        "answer_4": "$$-\\dfrac{5}{4}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Se define una función f cuyo dominio es $$\\mathbb{R}^{+}_{0}$$. La expresión que define a la función f es f(x) = $$\\sqrt{2x}$$. ¿Cuál es la expresión de la función f$$^{-1}$$(x)?",
        "answer_1": "f$$^{-1}$$(x) = $$\\dfrac{1}{2}$$ x$$^2$$",
        "answer_2": "f$$^{-1}$$(x) = $$\\dfrac{1}{4}$$ x$$^2$$",
        "answer_3": "f$$^{-1}$$(x) = 2x$$^2$$",
        "answer_4": "f$$^{-1}$$(x) = 4x$$^2$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Las rectas cuyas ecuaciones son $$x + 2y = 3$$ y $$x – ay – 4 = 0$$ son perpendiculares. Entonces, ¿cuál es el valor de $$a$$?",
        "answer_1": "$$\\dfrac{1}{2}$$",
        "answer_2": "$$\\dfrac{1}{4}$$",
        "answer_3": "$$-\\dfrac{1}{2}$$",
        "answer_4": "$$-\\dfrac{1}{4}$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si al punto $$\\mbox{P}=(1, 3)$$ se le aplica una rotación de $$180^{\\circ}$$ en torno al origen del plano cartesiano, ¿cuáles serán las nuevas coordenadas del punto resultante?",
        "answer_1": "$$(-1, -3)$$",
        "answer_2": "$$(-1, 3)$$",
        "answer_3": "$$(1, -3)$$",
        "answer_4": "$$(2, -6)$$",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "En la figura adjunta, el Δ ABC es rectángulo en C, D y E son puntos medios de $$\\overline{AB}$$ y $$\\overline{CA}$$, respectivamente y $$\\overline{AC}$$ = $$\\overline{BC}$$ = 2 cm. ¿ Cuál(es) de las siguientes proposiciones es(son) verdadera(s)? <br/><br/>I) El triángulo CDE es isóceles<br/>II) El área del triángulo CDE es 0,5 cm$$^{2}$$<br/>III) El perímetro del triángulo CDE es (2 + $$\\sqrt{2}$$)cm",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "I, II y III",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Geo_06.png"
        
    },
    {
        "statement": "En la ojiva de la figura adjunta se muestra la distribución de los puntajes de $$300$$ estudiantes en una prueba, donde los intervalos del gráfico son de la forma $$[a,b[$$ excepto el último que es de la forma $$[c,d]$$.",
        "answer_1": "El intervalo modal es $$\\left[750,850\\right]$$.",
        "answer_2": "Solo $$49$$ estudiantes obtuvieron menos de $$650$$ puntos.",
        "answer_3": "$$181$$ estudiantes obtiene más de $$650$$ puntos.",
        "answer_4": "Un $$25\\%$$ de los estudiantes obtiene menos de $$550$$ puntos.",
        "correct": "ansD",
        "opDiv": "opDivD",
        "imagePath":"/assets/imgForQs/Prob_05.png"
        
    },
    {
        "statement": "Respecto a una distribución estadística, ¿cuál de las siguientes afirmaciones es falsa?",
        "answer_1": "La mediana es el segundo cuartil.",
        "answer_2": "El segundo cuartil corresponde al percentil 50.",
        "answer_3": "El rango intercuartil corresponde a la diferencia entre el primer y tercer cuartil.",
        "answer_4": "El decil 75, corresponde al tercer cuartil y a su vez al percentil 75.",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Las autoridades de una ciudad, preocupadas por las altas tasas de alcoholismo, decidieron hacer una medición de la cantidad de vasos de alcohol que consume una persona por semana, obteniéndose los resultados mostrados en la siguiente tabla:<br/><br/>¿En qué intervalo se encuentra el tercer cuartil de la distribución?",
        "answer_1": "$$11 - 20$$",
        "answer_2": "$$21 - 30$$",
        "answer_3": "$$31 - 40$$",
        "answer_4": "$$41 - 50$$",
        "correct": "ansB",
        "opDiv": "opDivB",
        "imagePath":"/assets/imgForQs/Prob_06.png"
        
    },
    {
        "statement": "Al reducir al máximo $$\\displaystyle\\frac{\\sqrt{7+2\\sqrt{6}}}{\\sqrt{7-2\\sqrt{6}}}$$ se obtiene:",
        "answer_1": "$$7-\\sqrt{6}$$",
        "answer_2": "$$\\displaystyle\\frac{3\\sqrt{5}}{5}21 - 30$$",
        "answer_3": "$$\\displaystyle\\frac{7+\\sqrt{12}}{5}$$",
        "answer_4": "$$\\displaystyle\\frac{7+2\\sqrt{6}}{5}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "El valor de x en la ecuación 3 = 5$$^{x}$$ es :",
        "answer_1": "log 3 ∙ log 5",
        "answer_2": "$$\\dfrac{log 3}{log 5}$$",
        "answer_3": "1",
        "answer_4": "log 15",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "Si los catetos de un triángulo rectángulo se triplican, entonces, ¿cómo varía su hipotenusa?",
        "answer_1": "Es un 300$$\\%$$ de la original.",
        "answer_2": "Es un 600$$\\%$$ de la original.",
        "answer_3": "Es un 900$$\\%$$ de la original.",
        "answer_4": "Es un 90$$\\%$$ de la original.",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "Si $$f(x)=x^2-3$$ y $$h(z)=z+4$$, entonces el valor de $$3f(-1)+5h(2)$$ es:",
        "answer_1": "24",
        "answer_2": "36",
        "answer_3": "-6",
        "answer_4": "30",
        "correct": "ansA",
        "opDiv": "opDivA"
        
    },
    {
        "statement": "¿Cuántos números naturales cumplen la condición de que su décima parte es mayor o igual que su mitad disminuida en 2?",
        "answer_1": "2",
        "answer_2": "3",
        "answer_3": "4",
        "answer_4": "5",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si $$-6 \\geq 4t$$, entonces ¿cuáles son los valores de $$t$$?",
        "answer_1": "$$t \\geq -\\displaystyle \\frac{3}{2}$$",
        "answer_2": "$$t \\leq -\\displaystyle \\frac{3}{2}$$",
        "answer_3": "$$t < -\\displaystyle \\frac{3}{2}$$",
        "answer_4": "$$t \\leq -10$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El día lunes un artesano vendió $$15$$ aros y $$10$$ collares, obteniendo $$\\$90\\text{.}000$$ de recaudación entre ellos. El martes el artesano vendió $$6$$ aros y $$8$$ collares, recaudando entre ellos $$\\$60\\text{.}000$$. Si el artesano no cambió los precios de los aros y collares de un día a otro, ¿a qué valor está vendiendo cada collar?",
        "answer_1": "$$\\$2\\text{.}000$$",
        "answer_2": "$$\\$6\\text{.}000$$",
        "answer_3": "$$\\$2\\text{.}400$$",
        "answer_4": "$$\\$8\\text{.}000$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "Dada la ecuación $$(3m-1)x^2+4x-2=0$$, ¿qué condición debe cumplir m para que la ecuación NO tenga soluciones reales?",
        "answer_1": "$$m\\geq-\\dfrac{1}{3}$$",
        "answer_2": "$$m<-\\dfrac{1}{3}$$",
        "answer_3": "$$m<\\dfrac{1}{6}$$",
        "answer_4": "$$m<-\\dfrac{7}{6}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "La edad de Pedro es el doble de la edad de Ricardo, y la edad de Ximena es la mitad de la edad de Ricardo. Si la suma de sus edades es 63 años, ¿qué edad tiene Ximena??",
        "answer_1": "36 años",
        "answer_2": "24 años",
        "answer_3": "18 años",
        "answer_4": "9 años",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Si al punto $$A(7, -13)$$ le aplicamos una simetría con respecto al eje $$y$$ y luego una respecto al eje $$x$$, se obtiene el punto:",
        "answer_1": "$$(-7,-13)$$",
        "answer_2": "$$(-7,13)$$",
        "answer_3": "$$(-13,7)$$",
        "answer_4": "$$(-13,-7)$$",
        "correct": "ansB",
        "opDiv": "opDivB"
        
    },
    {
        "statement": "El punto medio entre dos puntos A y B es $$M(2,1)$$ y el vector director entre estos dos puntos es $$\\vec {d}=(4,-2)$$. Determinar los puntos A y B.",
        "answer_1": "A(0,2) y B(4,2)",
        "answer_2": "A(4,2) y B(4,0)",
        "answer_3": "A(4,0) y B(6,-2)",
        "answer_4": "A(0,2) y B(4,0)",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "El gobierno ha informado de un nuevo beneficio para el tratamiento de una enfermedad: la persona beneficiada deberá pagar solo el porcentaje correspondiente a los cuartiles sobre los cuales se encuentra. Por ejemplo, las personas pertenecientes al segundo cuartil pagan un $$50\\%$$ del tratamiento, correspondiente al porcentaje asociado al primer cuartil. Si una persona paga el $$50\\%$$ del tratamiento, ¿cuál es el cuartil al que pertenece?",
        "answer_1": "Primer cuartil",
        "answer_2": "Segundo cuartil",
        "answer_3": "Tercer cuartil",
        "answer_4": "Cuarto cuartil",
        "correct": "ansC",
        "opDiv": "opDivC"
        
    },
    {
        "statement": "En una urna hay $$3$$ bolas rojas numeradas del $$1$$ al $$3$$ y $$5$$ bolas amarillas numeradas del $$3$$ al $$7$$. Al extraer una bola al azar de la urna, ¿cuál es la probabilidad de sacar una bola roja o un número par?",
        "answer_1": "$$\\displaystyle \\frac{3}{8}$$",
        "answer_2": "$$\\displaystyle \\frac{6}{8}$$",
        "answer_3": "$$\\displaystyle \\frac{1}{2}$$",
        "answer_4": "$$\\displaystyle \\frac{5}{8}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    {
        "statement": "Un naipe inglés tiene $$52$$ cartas repartidas equitativamente en cuatro pintas. Si te entregan tres cartas del naipe al azar, sin reposición, ¿cuál es la probabilidad de que las tres cartas sean un trío de ases?",
        "answer_1": "$$\\displaystyle\\frac{1}{4^3}$$",
        "answer_2": "$$\\displaystyle\\frac{1}{13^3}$$",
        "answer_3": "$$\\displaystyle\\frac{4\\cdot3\\cdot2}{52^3}$$",
        "answer_4": "$$\\displaystyle\\frac{4\\cdot3\\cdot2}{52\\cdot51\\cdot50}$$",
        "correct": "ansD",
        "opDiv": "opDivD"
        
    },
    


    //SCIENCE------------------------
    {
        "statement": "Si una célula es puesta en un medio hipotónico, ingresara gran cantidad de agua y se diluirá su contenido. En las células animales esto podría generar la ruptura de la célula, en cambio en las células vegetales nunca llega a romperse.<br/>¿Cuál es la razón por la que no estalla la célula vegetal?",
        "answer_1": "Por las vacuolas que almacenan gran cantidad de agua.",
        "answer_2": "Por los cloroplastos que requieren continuamente agua para la fotosíntesis.",
        "answer_3": "Por la pared vegetal que ejerce una fuerza contraria a la fuerza de ingreso del agua",
        "answer_4": "Por la membrana plasmática que es más permeable a la entrada y salida de agua",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿En qué etapa del ciclo celular se produce la máxima compactación de la cromatina?",
        "answer_1": "Interfase",
        "answer_2": "Metafase",
        "answer_3": "Telofase",
        "answer_4": "G1",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "El cigoto, producto de la fecundación, es implantado en el endometrio:",
        "answer_1": "Los dos primeros días después de la fecundación",
        "answer_2": "La tercera semana después de la fecundación",
        "answer_3": "Las 24 horas después de la fecundación",
        "answer_4": "Entre el séptimo y undécimo día después de la fecundación",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "En el caso de un rasgo fenotípico que se hereda según el modelo mendeliano,la proporción fenotípica que se observará en la descendencia de un homocigoto dominante: <br/><br/>I) es independiente del genotipo del otro progenitor.<br/>II) es impredecible.<br/>III)dependerá del genotipo del otro progenitor.",
        "answer_1": "Solo I.",
        "answer_2": "Solo II.",
        "answer_3": "Solo I y III.",
        "answer_4": "I, II y III.",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "Las rémoras son peces que usualmente viven relacionándose con especies más grandes, como tiburones. Esto no afecta a los tiburones, pero les entrega protección, alimento y transporte a las rémoras. ¿Cómo podría definirse la relación entre rémoras y tiburones?",
        "answer_1": "Comensalismo",
        "answer_2": "Simbiosis",
        "answer_3": "Competencia",
        "answer_4": "Parasitismo",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "Una planta que se encuentra en condiciones óptimas para desarrollar fotosíntesis, deja de realizarla debido a que sus estomas se encuentran cerrados. Si se desea realizar un análisis a las variables que pueden encontrarse involucradas en este fenómeno, ¿cuál de ellas debiese descartar antes de llevarlo a cabo?",
        "answer_1": "Cantidad de luz.",
        "answer_2": "Cantidad de agua.",
        "answer_3": "Temperatura.",
        "answer_4": "Concentración de sales del suelo.",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "El sonido se puede:<br/><br/>I) Refractar<br/>II) Difractar<br/>III) Reflejar<br/>Es(son) correctas:",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo II y III",
        "answer_4": "I, II y III",
        "correct": "ansD",
        "opDiv": "opDivD"
    },
    {
        "statement": "Con respecto a la sombra y penumbra, se afirma que:<br/><br/>I) si la fuente es puntual, se forma una sombra de un cuerpo opaco.<br/>II) la formación de sombra y penumbra depende de la distancia entre la fuente de luz y el cuerpo opaco.<br/>III) se forman porque los rayos luminosos se mueven en línea recta.<br/>Es (son) correcta(s):",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo I y III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "Un objeto posee una masa inicial m y una rapidez v, pero en una situación posterior su masa aumenta al triple y su rapidez disminuye a la mitad. La razón entre el momento lineal inicial y final es:",
        "answer_1": "$$\\frac{3}{2}$$",
        "answer_2": "$$\\frac{2}{3}$$",
        "answer_3": "$$\\frac{9}{4}$$",
        "answer_4": "$$\\frac{4}{9}$$",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Dos patinadores están sobre la superficie de un lago congelado, donde se considera el roce nulo. Si el primer patinador empuja al segundo patinador con una fuerza , estando ambos inicialmente en reposo. Dado lo anterior, es correcto afirmar que:",
        "answer_1": "Sólo el segundo se mueve.",
        "answer_2": "Ambos se mueven en el mismo sentido",
        "answer_3": "Los dos quedan en reposo.",
        "answer_4": "Ambos se mueven en sentido opuesto.",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "La temperatura de un cuerpo aumenta hasta los 10°C. Entonces en el cuerpo tenemos:",
        "answer_1": "un calor igual a 10 calorías.",
        "answer_2": "un aumento de la energía cinética de las moléculas.",
        "answer_3": "una disminución de la energía cinética.",
        "answer_4": "un aumento en la capacidad calórica.",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "Si un ión de carga $$+3$$ tiene la configuración $$1s^{2}$$ $$2s^{2}$$ $$2p^{4}$$, el número atómico que originó el ión es:",
        "answer_1": "13",
        "answer_2": "8",
        "answer_3": "11",
        "answer_4": "4",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál(es) de las siguientes moléculas posee(n) un carbono quiral?<br/><br/>I) Etanamida<br/>II) Propanamida<br/>III) Ácido-2-aminobutanoico",
        "answer_1": "Solo I",
        "answer_2": "Solo II",
        "answer_3": "Solo III",
        "answer_4": "I, II y III",
        "correct": "ansC",
        "opDiv": "opDivC"
    },
    {
        "statement": "¿Cuál es el número de isómeros estructurales de la especie química de fórmula molecular $$C_2H_4Br_2$$?",
        "answer_1": "1",
        "answer_2": "2",
        "answer_3": "3",
        "answer_4": "4",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "¿Cuántos gramos de NaCl (Masa molar = 58 g/mol) se necesitan para 100 mL de solución a 0,3 M?",
        "answer_1": "1,74 gramos",
        "answer_2": "0,174 gramos",
        "answer_3": "17,4 gramos",
        "answer_4": "174 gramos",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "El agua de mar tiene:",
        "answer_1": "mayor presión de vapor que el agua potable.",
        "answer_2": "mayor densidad que el agua dulce.",
        "answer_3": "el mismo punto de ebullición del agua pura.",
        "answer_4": "un punto de congelación mayor que el agua pura.",
        "correct": "ansB",
        "opDiv": "opDivB"
    },
    {
        "statement": "¿Cómo se denomina el proceso mediante el cual, el agua pasa desde una solución diluida a otra más concentrada?",
        "answer_1": "Osmosis",
        "answer_2": "Dispersión",
        "answer_3": "Insaturación",
        "answer_4": "Homogenización",
        "correct": "ansA",
        "opDiv": "opDivA"
    },
    {
        "statement": "En relación a las propiedades coligativas se puede decir que:",
        "answer_1": "si se disuelve en agua un soluto volátil, aumenta su temperatura de ebullición.",
        "answer_2": "dependen solo de la concentración de soluto en la disolución y no de la naturaleza de este.",
        "answer_3": "se estudian disoluciones concentradas, cuyas concentraciones superan los 0,2M.",
        "answer_4": "al agregar un soluto no volátil a un disolvente puro, la presión de vapor que se obtiene es mayor que la original.",
        "correct": "ansB",
        "opDiv": "opDivB"
    }
];

